package edu.niu.z1915865.mathsums;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.security.auth.Subject;

//Math Operations Screen..
public class SecondActivity extends AppCompatActivity {

    //Declaring variables and views..
    int count = 0 ;
    Button Next ;
    TextView N1 , N2 , OP, tvCorrect, tvWrong;
    EditText editText ;
    List<Integer> num1list ;
    List<Integer> num2list ;
    List<String> strings = new ArrayList<>();
    int i = 0 ;
    RelativeLayout r1, r2;
    ScrollView scroll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        //Random numbers 2 lists initialization..
        num1list = new ArrayList<>();
        num2list = new ArrayList<>();
        for(int i = 1 ; i<=10 ;i++ )
        {
            num1list.add(i);
            num2list.add(i);
        }

        //Shuffle lists function shuffle the numbers from 1 to 10 to change their position random.
        Collections.shuffle(num1list);
        Collections.shuffle(num2list);
        strings = FirstActivity.stringList;

        //View initialization..
        N1 = findViewById(R.id.num1);
        N2 = findViewById(R.id.num2);
        OP = findViewById(R.id.op);
        tvCorrect = findViewById(R.id.tvCorrect);
        tvWrong = findViewById(R.id.tvWrong);
        editText = findViewById(R.id.answer);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        scroll = findViewById(R.id.scroll);

        //Set numbers and operation to textview(That is currently shown)..
        N1.setText(num1list.get(i)+"");
        N2.setText(num2list.get(i)+"");
        int min = 0;
        int max = strings.size()-1;

        //Increment counter to point out next random numbers from list..
        i++;

        //Generate random int value to get any random operation from list that user select operations from First Screen.
        //Every time a random operation is selected from list..
        int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);

        OP.setText(strings.get(random_int));

        Next = findViewById(R.id.next);

        //Click Next Button OnClickListener code..
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get both numbers and operation from textviews that is currently shown
                float n  = Float.parseFloat(N1.getText().toString());
                float n1  = Float.parseFloat(N2.getText().toString());
                String s = OP.getText().toString();

                //Get user answer from editext..
                String Answer = editText.getText().toString();
                if(editText.getText().toString().isEmpty()){
                    editText.setError("Field is empty");
                    return;
                }
                float ans = Float.parseFloat(Answer);


                //Determine which operation is currently shown on screen to perform appropriate operation on numbers..Like +,-,* or /
                if(s.equals("+")){
                    //This condition check user entered correct answer or not..If answer is correct increment the counter..
                    if((n+n1)==ans){
                        count++;
                        editText.setText("");
                    }else {
                        editText.setText("");
                    }
                }
                else if(s.equals("-")){
                    if((n-n1)==ans){
                        count++;
                        editText.setText("");
                    }else {
                        editText.setText("");
                    }
                }
                else if(s.equals("*")){
                    if((n*n1)==ans){
                        count++;
                        editText.setText("");
                    }else {
                        editText.setText("");
                    }
                }
                else if(s.equals("/")){
                    if((n/n1)==ans){
                        count++;
                        editText.setText("");
                    }else {
                        editText.setText("");
                    }
                }

                //After checking user answer simply get next numbers from random lists and display on views on screen.
                //This condition is check whether 10 questions are completed or not..
                if(i<num1list.size()){
                    N1.setText(num1list.get(i)+"");
                    N2.setText(num2list.get(i)+"");
                    int min = 0;
                    int max = strings.size()-1;

                    int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);

                    OP.setText(strings.get(random_int));


                    i++;
                }else {

                    //If 10 questions are completed this part of code executed and display result to user,,
                    scroll.setVisibility(View.GONE);
                    r2.setVisibility(View.VISIBLE);
                    int wrong = 10-count;
                    tvCorrect.setText("Total Correct : "+count);
                    tvWrong.setText("Total Wrong : "+wrong);
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        FirstActivity.stringList.clear();
        super.onBackPressed();
        finish();
    }
}