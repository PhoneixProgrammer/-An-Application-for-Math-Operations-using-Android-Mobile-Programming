package edu.niu.z1915865.mathsums;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import java.util.ArrayList;
import java.util.List;
//This Activity is First Screen shown to user that contains Addition, Subtraction, Multiplication and Division opions.
public class FirstActivity extends AppCompatActivity {

    //Declaring variables and views..
   public static List<String> stringList  ;
    Button Submit;
    CheckBox c1 , c2 ,c3 ,c4 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        //View initialization..
        c1 = findViewById(R.id.cbadd);
        c2 = findViewById(R.id.cbsub);
        c3 = findViewById(R.id.mul);
        c4 = findViewById(R.id.devide);

        stringList = new ArrayList<>();
        Submit = findViewById(R.id.submit);

        //Submit button OnClickListener code that store user selection in a list and moves to math operations screen..
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Check that which options user is selected...
                if(c1.isChecked()){
                    stringList.add("+");
                    c1.setChecked(false);
                }
                if(c2.isChecked()){
                    stringList.add("-");
                    c2.setChecked(false);
                }
                if(c3.isChecked()){
                    stringList.add("*");
                    c3.setChecked(false);
                }
                if(c4.isChecked()){
                    stringList.add("/");
                    c4.setChecked(false);
                }

                startActivity(new Intent(getApplicationContext() , SecondActivity.class));

            }
        });


    }






}